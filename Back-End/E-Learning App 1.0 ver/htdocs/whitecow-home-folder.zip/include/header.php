<!DOCTYPE html>
<head>
<title>INDEX</title>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="/whitecow-home-folder/css/common.css">
<script type="text/javascript" src="/whitecow-home-folder/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="/whitecow-home-folder/js/common.js"></script>
</head>
<body>