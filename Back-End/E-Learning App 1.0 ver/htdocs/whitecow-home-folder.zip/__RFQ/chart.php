<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <?php
        $db = mysqli_connect("localhost", "root", "gusdn123", "photos");
        $sql = "SELECT * FROM images";
        $result = mysqli_query($db, $sql);

        $cnt = array();

while($row = mysqli_fetch_array($result)){
    /*echo "<div id = 'img_div'>";
      echo "<img src='images/".$row['image']."' >";
      echo "<p>".$row['text']."</p>";
    echo "</div>";*/
    $price = $row['price'];
    array_push($cnt, $price);
  }?>

    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);
      
      var cnt = <?php echo json_encode($cnt)?>;

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['price', 'price'],
          ['price1', cnt[0]],
          ['price2', cnt[1]],
          ['price3', cnt[2]],
          ['price4', cnt[3]],
          ['price5', cnt[4]],
          ['price6', cnt[5]]
        ]);

        var options = {
          chart: {
            title: 'Comparing Price',
            subtitle: 'Price',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>

  </head>
  <body>
    <div id="barchart_material" style="width: 900px; height: 500px;"></div>
  </body>
</html>