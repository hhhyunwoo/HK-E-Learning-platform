<?php
  include "../../include/db.php"; 
  //include "../../include/header.php";
  //include "../../include/menu.php";


  //$sql = mq("select * from member where id='".$_POST['userid']."'");
  //echo $sql;


 


  if(isset($_POST['upload'])){
    
    //$db = mysqli_connect("101.101.164.113", "root", "root", "photos");
    $db = mysqli_connect("localhost", "root", "gusdn123", "photos");
    $id = $_SESSION['userid'];

    $price = $_POST['price'];
    //$ididid = "hwk";
    $sql = "INSERT INTO request_price (idx, price, idid) 
        VALUES(1,'$price',
              '$id')";

    //images 테이블에 이미지정보를 저장하자.
    
    mysqli_query($db,$sql);
    mysqli_close($db);

       //$msg = "Image uploaded successfully";
    //echo $msg;
      }

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Shop Item - Start Bootstrap Template</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/shop-item.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">실시간 입찰 시스템</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">
        <h1 class="my-4">Shop Name</h1>
        <div class="list-group">
          <a href="..\index_AM.php" class="list-group-item">RFQ List</a>
          <a href=".\Request.php" class="list-group-item">Requset For Quotation</a>
          <a href="#" class="list-group-item">Contact</a>
        </div>
      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div class="card mt-4">
          <img class="card-img-top img-fluid" src="img\9_4_item1.jpg" alt="">
          <div class="card-body">
            <h3 class="card-title">Assy charger inlet & cover Actuator for Tesla</h3>
            <h4>2 Quotes</h4>
            <p class="card-text">Connect to the Global Automotive Industry Global sourcing starts here. Worldwide Manufacturers List Search database by material & processing, parts and more categories. </p>
            <span class="text-warning">&#9733; &#9733; &#9733; &#9733; &#9734;</span>
            4.0 stars
          </div>
        </div>
        <!-- /.card -->

        <div class="card card-outline-secondary my-4">
          <div class="card-header">
            Product Reviews
          </div>
          <div class="card-body">
            <p>This is awesome!!</p>
            <small class="text-muted">Posted by Anonymous on 5/25/19</small>
            <hr>
            <p>Let's get it!!</p>
            <small class="text-muted">Posted by Anonymous on 5/25/19</small>
            <hr>
            <p>That's Great!!!</p>
            <small class="text-muted">Posted by Anonymous on 5/25/19</small>
            <hr>

              <form method="post" action="./itemContent.php"
                  enctype="multipart/form-data">
                  <div>
                    <textarea name="price" cols="40" rows="4"
                    placeholder="How much can you pay?"></textarea>
                  </div>
                  <div>
                    <input type="submit" name="upload" value="Upload Text">
                  </div>
              </form>

            <a href="..\chart.php" class="btn btn-success">Chart</a>
          </div>

        </div>
        <!-- /.card -->

      </div>
      <!-- /.col-lg-9 -->

    </div>

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
