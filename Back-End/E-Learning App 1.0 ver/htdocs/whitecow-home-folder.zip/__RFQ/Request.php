<?php
	$msg = "";
	define ('SITE_ROOT', realpath(dirname(__FILE__)));

	if(isset($_POST['upload'])){
		//echo $file = $_FILES['image']['tmp_name'];
		$target = "/images/".basename($_FILES['image']['name']);
		
		if (file_exists($target)) {
    		echo "Sorry, file already exists.";
    		$uploadOk = 0;
		}
		else if (move_uploaded_file($_FILES['image']['tmp_name'], SITE_ROOT.$target)) {
		/*database에 업로드 정보를 기록하자.
		- 파일이름(혹은 url)
		- 파일사이즈
		- 파일형식
		*/
		//$db = mysqli_connect("101.101.164.113", "root", "root", "photos");
		$db = mysqli_connect("localhost", "root", "gusdn123", "photos");
		$image = $_FILES['image']['name'];
		$text = $_POST['text'];
		$price = $_POST['price'];

		$sql = "INSERT INTO images (id, image, text, price) 
				VALUES(1,'$image',
					'$text',
					'$price')";
					
		//images 테이블에 이미지정보를 저장하자.
		
		mysqli_query($db,$sql);
		mysqli_close($db);

        //$msg = "Image uploaded successfully";
		//echo $msg;
		//echo "<p>The file ". basename( $_FILES["image"]["name"]). " has been uploaded.</p>";
   		}
	}

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Autoin.com - 견적 제출하기</title>

    <!-- Bootstrap core CSS -->
    <link href="./vendor/bootstrap/css/bootstrap.min.css?ver=1" rel="stylesheet">
    <link rel="stylesheet" href="./css/bootstrap.min.css?ver=1">

    <!-- Custom styles for this template -->
    <link href="./css/shop-item.css?ver=1" rel="stylesheet">

</head>
<body>
  <!-- Navigation -->




  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">
        <h1 class="my-4">Requset For Quotes</h1>
        <div class="list-group">
          <a href="./index_AM.php" class="list-group-item">RFQ List</a>
          <a href="./Request.php" class="list-group-item">Requset For Quotation</a>
          <a href="#" class="list-group-item">Contact</a>
        </div>
      </div>
      <!-- /.col-lg-3 -->

        <!-- /.card -->



        <div class="col-lg-9">
					<!-- General Unify Forms -->


					<hader>1. Photo</hader>
					



						<fieldset>
              <div style="border:1px solid; padding:10px;">
							<section>

								<form method="post" action="./Request.php"
									enctype="multipart/form-data">
										<input type="hidden" name="size" value="1000000">
									<div>
										<input type="file" name="image">
									</div>
									<div>
										<textarea name="text" cols="40" rows="4"
										placeholder="Say something"></textarea>
									</div>
									<div>
										<textarea name="price" cols="10" rows="2"
										placeholder="price"></textarea>
									</div>
									<div>
										<input type="submit" name="upload" value="Upload Image">
									</div>
									<div>
										<input type="submit" name="Blockchain Button" value="Blockchain">
									</div>
								</form>
								
							</section>
            	</div>
						</fieldset>


						<header>2. Certificated</header>

						<fieldset>
              <div style="border:1px solid; padding:10px;">
							<section>
								<!--<label class="label">Certificated</label>-->
								<div class="row">
									<div class="col col-4">
										<label class="checkbox"><input type="checkbox" name="certificated" value="No"><i></i>No</label>
										<label class="checkbox"><input type="checkbox" name="certificated" value="ISO 14001"><i></i>ISO 14001</label>
									</div>
									<div class="col col-4">
										<label class="checkbox"><input type="checkbox" name="certificated" value="ISO/TS 16949"><i></i>ISO/TS 16949</label>
										<label class="checkbox"><input type="checkbox" name="certificated" value="ISO 26262"><i></i>ISO 26262</label>
									</div>
									<div class="col col-4">
										<label class="checkbox"><input type="checkbox" name="certificated" value="ISO 9001"><i></i>ISO 9001</label>
									</div>
								</div>
							</section>
            </div>
						</fieldset>

						<header>3. Describe Your Part & Upload Your Files</header>

						<fieldset>
              <div style="border:1px solid; padding:10px;">
							<section>
								<label class="label">Part Name</label>
								<label class="input">
									<input type="text" name="partName" id="partName" placeholder="Bushing, Engine Mount" value="">
								</label>
							</section>

							<section>
								<label class="label">Description</label>
								<label class="textarea">
									<textarea name="description" id="description" rows="6"></textarea>
								</label>
							</section>

							<section>
								<label class="label">Due Date</label>
								<label class="input">
									<i class="icon-append fa fa-calendar"></i>
									<input type="text" name="dueDate" id="date" placeholder="Quotes Needed By" value="">
								</label>
							</section>

            </div>
						</fieldset>



						<footer class="text-center">
							<button type="button" class="btn-u btn-u-default btn-u-lg" onclick="window.history.back();">Back</button>
							<button type="submit" class="btn-u btn-u-lg">Submit RFQ</button>
						</footer>

					</form>
					<!-- General Unify Forms -->
				</div>
				<!-- End Content -->
  </div>
  <!-- /.container -->
</div>

</body>
</html>
