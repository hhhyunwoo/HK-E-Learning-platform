<?php

$conn = mysqli_connect("localhost","root","gusdn123","login");
mysqli_select_db($conn,"login");
?>